package com.company.entity;

public enum PaymentMethod {
    CARD,
    CASH,
    ONLINE
}
