package com.company.entity.approval;

public enum ApprovalType {
    예약, 결제, 주문_승인, 반품_승인;
}
