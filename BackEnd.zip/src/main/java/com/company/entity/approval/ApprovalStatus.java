package com.company.entity.approval;

public enum ApprovalStatus {
    승인, 거절;
}
