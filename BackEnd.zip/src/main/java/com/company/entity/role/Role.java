package com.company.entity.role;

public enum Role {
    USER, ADMIN;
}
