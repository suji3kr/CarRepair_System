package com.company.entity.notification;

public enum NotificationStatus {
    읽음, 안읽음;
}
