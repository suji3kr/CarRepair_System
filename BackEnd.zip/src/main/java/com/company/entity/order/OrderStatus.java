package com.company.entity.order;

public enum OrderStatus {
    PENDING, SHIPPED, DELIVERED, CANCELLED, RETURNED;
}
