package com.company.entity;

public enum PaymentStatus {
    PENDING,
    COMPLETED,
    FAILED
}
