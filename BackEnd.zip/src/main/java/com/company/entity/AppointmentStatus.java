package com.company.entity;

public enum AppointmentStatus {
    예약, 진행중, 완료;
}
