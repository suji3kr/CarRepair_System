package com.company.dto;

public record ApiResponse(String message) {}