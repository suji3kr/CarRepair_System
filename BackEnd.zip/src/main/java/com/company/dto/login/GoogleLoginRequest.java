package com.company.dto.login;

import lombok.Data;

@Data
public class GoogleLoginRequest {
    private String tokenId;
}
