package com.company.dto.login;

import lombok.Data;

@Data
public class JwtResponse {
    private String token;

    // Constructor, Getter, Setter
}
