package com.company.dto.chat;

import lombok.Data;

@Data
public class ChatRequest {
    private String message;
}
