export interface ChatRequest {
  message: string;
}

export interface ChatResponse {
  answer: string;
}